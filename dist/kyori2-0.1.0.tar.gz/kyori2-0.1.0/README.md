A small command execute programe

[Github](https://github.com/sichang824/kyori2.git)

A small command execute programe

[Github-flavored Markdown](https://git.code.tencent.com/andrew75567/kyori2.git)
